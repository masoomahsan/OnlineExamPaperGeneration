package jtc.UserRegistration;

public interface UserRegistrationDAO {
	public int addUser(User user) throws Exception;
}
