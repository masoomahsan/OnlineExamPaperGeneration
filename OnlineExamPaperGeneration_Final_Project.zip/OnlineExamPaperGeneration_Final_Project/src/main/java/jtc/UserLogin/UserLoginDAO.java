package jtc.UserLogin;

public interface UserLoginDAO {
	public boolean UserLogin(UserLogin login) throws Exception;
}
